package ca.on.Conestoga.col;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class StatisticsActivity extends AppCompatActivity  implements View.OnClickListener {

    private Button reset;


    private TextView winandlose ,winandlastlose;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        setTheme(((FingersGameApp)getApplication()).getActivatedTheme());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);

        }
        reset= findViewById(R.id.reset);
        winandlose = findViewById(R.id.winandlossall);
        winandlastlose= findViewById(R.id.winandlostlatest);


        int winlast = ((FingersGameApp)getApplication()).getLastWin();
        int loselast = ((FingersGameApp)getApplication()).getLastLose();

        winandlastlose.setText(winlast+"-"+loselast);

        int win = ((FingersGameApp)getApplication()).getTotalWon();
        int lose = ((FingersGameApp)getApplication()).getTotallostGames();

        winandlose.setText(win+"-"+lose);


        reset.setOnClickListener(this);





    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:

                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }




    }

    @Override
    public void onBackPressed() {

        finish();

        Intent i = new Intent(this,MainActivity.class);
        startActivity(i);



    }


    @Override
    public void onClick(View v) {
        ((FingersGameApp)getApplication()).resetButton();
        finish();
        startActivity(getIntent());
    }
}
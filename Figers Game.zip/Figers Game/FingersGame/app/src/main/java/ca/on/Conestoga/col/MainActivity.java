package ca.on.Conestoga.col;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

import android.animation.Animator;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener {

    private Button oneFinger;
    private Button twoFinger;
    private ImageButton leftImage;
    private ImageButton rightImage;
    private TextView txtResult;
    int myMove,compMove;
    Timer timer ;



    @Override
    protected void onCreate(Bundle savedInstanceState) {


        setTheme(((FingersGameApp)getApplication()).getActivatedTheme());

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        timer=new Timer(true) ;

        oneFinger = findViewById(R.id.btnOne);
        twoFinger = findViewById(R.id.btnTwo);

        leftImage = findViewById(R.id.imgBtnComp);
        rightImage = findViewById(R.id.imgBtnYou);

        txtResult = findViewById(R.id.textViewresult);

        oneFinger.setOnClickListener(this);
        twoFinger.setOnClickListener(this);



        leftImage.setVisibility(View.INVISIBLE);
        rightImage.setVisibility(View.INVISIBLE);

        load_previous();
        startService(new Intent(this,CheeringService.class));

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.fingergame_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {


        if(item.getItemId()==R.id.msettings){

            Intent settings= new Intent(MainActivity.this,SettingsActivity.class);
            startActivity(settings);

        }
        else if(item.getItemId()==R.id.mstatistics){

            Intent statistics= new Intent(MainActivity.this, StatisticsActivity.class);
            startActivity(statistics);
        }


        return true;
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("pause","y");

        HashMap<String,String> mp = new HashMap<String, String>();
        mp.put("maintext",txtResult.getText().toString());
        mp.put("handcomp",Integer.toString(compMove));
        mp.put("handuser",Integer.toString(myMove));

        ((FingersGameApp)getApplication()).setData(mp);



    }

    @Override
    protected void onResume() {
        super.onResume();

    }



    @Override
    public void onClick(View v) {



         compMove= (int) ( Math.random() * 2 + 1);

         if(v.getId()==R.id.btnOne){

             myMove=1;
             rightImage.setImageResource(R.drawable.ic_one);


         }
         if(v.getId()==R.id.btnTwo){

             myMove=2;

             rightImage.setImageResource(R.drawable.ic_two);

         }

        if(compMove==1){
            leftImage.setImageResource(R.drawable.ic_one);
        }
        else{
            leftImage.setImageResource(R.drawable.ic_two);
        }

        showResult();

    }


    private  void showResult(){

         int  result = myMove+compMove;

         if(result%2==0){

             txtResult.setText("You Win");
             ((FingersGameApp)getApplication()).saveGameToDatabase(1);


         }else{
             txtResult.setText("Computer Win");
             ((FingersGameApp)getApplication()).saveGameToDatabase(0);
         }






         leftImage.setVisibility(View.VISIBLE);
         rightImage.setVisibility(View.VISIBLE);
         leftImage.setAlpha(0f);
         txtResult.setAlpha(0f);
         rightImage.setAlpha(0f);

        rightImage.animate().alpha(1).setDuration(1000);


       rightImage.animate().alpha(1).setDuration(1000).setListener(new Animator.AnimatorListener() {
           @Override
           public void onAnimationStart(Animator animation) {

           }

           @Override
           public void onAnimationEnd(Animator animation) {

               leftImage.animate().alpha(1).setDuration(1000).setListener(new Animator.AnimatorListener() {
                   @Override
                   public void onAnimationStart(Animator animation) {
                       txtResult.animate().alpha(1).setDuration(1000);
                   }

                   @Override
                   public void onAnimationEnd(Animator animation) {

                   }

                   @Override
                   public void onAnimationCancel(Animator animation) {

                   }

                   @Override
                   public void onAnimationRepeat(Animator animation) {

                   }
               });

           }

           @Override
           public void onAnimationCancel(Animator animation) {

           }

           @Override
           public void onAnimationRepeat(Animator animation) {

           }
       });




         /*waiting for  3 seconds and starting  if user is not replaying */



        timer.schedule(new TimerTask() {
            @Override
            public void run() {

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),"Keep playing you know you want to",Toast.LENGTH_LONG).show();
                    }
                });


            }
        },3000);







    }


    public void  load_previous(){

        Log.d ("what",""+((FingersGameApp)getApplication()).getGameStatus());

        if(((FingersGameApp)getApplication()).getGameStatus()==true){

            compMove = Integer.parseInt( ((FingersGameApp)getApplication()).getCompMove());
            myMove = Integer.parseInt( ((FingersGameApp)getApplication()).getMyMove());
            txtResult.setText(((FingersGameApp)getApplication()).getMainText());

            if(myMove==1){


                rightImage.setImageResource(R.drawable.ic_one);


            }
            if(myMove==2){

                rightImage.setImageResource(R.drawable.ic_two);

            }

            if(compMove==1){
                leftImage.setImageResource(R.drawable.ic_one);
            }
            else{
                leftImage.setImageResource(R.drawable.ic_two);
            }

            leftImage.setVisibility(View.VISIBLE);
            rightImage.setVisibility(View.VISIBLE);

        }else{

            leftImage.setVisibility(View.INVISIBLE);
            rightImage.setVisibility(View.INVISIBLE);

        }


    }



}
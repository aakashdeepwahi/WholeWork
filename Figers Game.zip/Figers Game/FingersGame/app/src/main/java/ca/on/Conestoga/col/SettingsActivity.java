package ca.on.Conestoga.col;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NavUtils;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        setTheme(((FingersGameApp)getApplication()).getActivatedTheme());

        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.settings, new SettingsFragment())
                .commit();
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);

        }
    }

    public static class SettingsFragment extends PreferenceFragmentCompat {
        @Override
        public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
            setPreferencesFromResource(R.xml.root_preferences, rootKey);


            Preference themepref = (Preference) findPreference("dark_theme_activated");
            themepref.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    if(Boolean.parseBoolean(""+newValue)){

                        ((FingersGameApp) getActivity().getApplication()).setDarkTheme(true);

                    }else{

                        ((FingersGameApp) getActivity().getApplication()).setDarkTheme(false);
                    }

                    return true;
                }
            });


            Preference game_save_pref = (Preference) findPreference("game_must_save");
            game_save_pref.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    if(Boolean.parseBoolean(""+newValue)){

                        ((FingersGameApp)getActivity().getApplication()).setGameStatus(1);
                    }else{

                        ((FingersGameApp)getActivity().getApplication()).setGameStatus(2);
                    }

                    return true;
                }
            });




        }




    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:

                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }




    }

    @Override
    public void onBackPressed() {

        finish();

      Intent i = new Intent(this,MainActivity.class);
      startActivity(i);



    }
}
package ca.on.Conestoga.col;

import android.app.Application;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.preference.PreferenceManager;

import java.util.HashMap;

public class FingersGameApp extends Application {
    private SharedPreferences sharedPreferences;
    private static  final String DBNAME="db_fingers";
    private static final  int DBVERSION=1;
    private  SQLiteOpenHelper helper=null;

    @Override
    public void onCreate() {


        helper =new SQLiteOpenHelper(this,DBNAME,null,DBVERSION){

            @Override
            public void onCreate(SQLiteDatabase db) {
                db.execSQL("CREATE TABLE IF NOT EXISTS statistics( status integer, times text )");
            }

            @Override
            public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

            }



        };

        super.onCreate();
    }


    public void  saveGameToDatabase(int result){

        SQLiteDatabase db = helper.getWritableDatabase();




       String query="insert into statistics(status,times) values ("+result+",'" +Math.round(System.currentTimeMillis() / 1000) +"') ";


        db.execSQL(query);




    }


    public  int  getTotalWon(){

        SQLiteDatabase database = helper.getReadableDatabase();

        Cursor cu = database.rawQuery("select COUNT(status) FROM statistics where status=1 ",null);

        cu.moveToFirst();

        int  count = cu.getInt(0);

        cu.close();


        return count;
    }



    public  int  getTotallostGames(){

        SQLiteDatabase database = helper.getReadableDatabase();

        Cursor cu = database.rawQuery("select COUNT(status) FROM statistics where status=0",null);

        cu.moveToFirst();

        int  count = cu.getInt(0);

        cu.close();


        return count;
    }




    public  void resetButton(){


        SQLiteDatabase database = helper.getReadableDatabase();
        database.delete("statistics","",null);


    }



    public  int  getLastWin(){

        SQLiteDatabase database = helper.getReadableDatabase();

        Cursor cu = database.rawQuery("select COUNT(status) FROM statistics  where status=1 and times="+Math.round(System.currentTimeMillis() / 1000),null);

        cu.moveToFirst();

        int  count = cu.getInt(0);

        cu.close();



        return count;
    }



    public  int  getLastLose(){

        SQLiteDatabase db = helper.getReadableDatabase();

        Cursor cu = db.rawQuery("select COUNT(status) FROM statistics where status=0 and  times = "+Math.round(System.currentTimeMillis() / 1000),null);

        cu.moveToFirst();

        int  count = cu.getInt(0);

        cu.close();


        return count;
    }




    public int  getActivatedTheme()
    {
        PreferenceManager.setDefaultValues(this,R.xml.root_preferences,false);

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);

        if(sharedPreferences.getBoolean("dark_theme_activated",false)) {



           return R.style.darkTheme;
        }
        else{
            return R.style.AppTheme;
        }


    }

    public void setDarkTheme(boolean value){

        PreferenceManager.setDefaultValues(this,R.xml.root_preferences,false);

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);

        sharedPreferences.edit().putBoolean("dark_theme_activated",value).commit();
    }


















    public void setData(HashMap<String,String> hashMap){

        sharedPreferences.edit().putString("maintext",hashMap.get("maintext")).commit();
        sharedPreferences.edit().putString("handcomp",hashMap.get("handcomp")).commit();
        sharedPreferences.edit().putString("handuser",hashMap.get("handuser")).commit();

    }


    public String getMainText(){
       return sharedPreferences.getString("maintext","");
    }

    public String getMyMove(){
        return sharedPreferences.getString("handcomp","");
    }

    public String getCompMove(){
        return sharedPreferences.getString("handuser","");
    }


    public void setGameStatus(int i){
        if(i==1){

            sharedPreferences.edit().putBoolean("game_must_save",true).commit();

        }
        else{
            sharedPreferences.edit().putBoolean("game_must_save",false).commit();
        }

    }

    public boolean getGameStatus(){

        if(sharedPreferences.getBoolean("game_must_save",false)){
            return  true;
        }else{
            return false;
        }
    }












}

package ca.on.Conestoga.col;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import java.util.Timer;
import java.util.TimerTask;

public class CheeringService extends Service {
    Timer timer;
    private Notification.Builder notificationb;
    private  Notification notification;
    private String CHANNELID="validexample";
    private  String description = "",name = "FingersGame";

    public CheeringService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
return  null;
    }

    @Override
    public void onCreate() {
        super.onCreate();


       timer = new Timer();
       timer.schedule(new TimerTask() {
            @Override
            public void run() {




                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

                    notificationb = new Notification.Builder(getApplicationContext(), CHANNELID);


                } else {

                      notificationb = new Notification.Builder(getApplicationContext());


                }

               notification = notificationb.setSmallIcon(R.drawable.ic_launcher_foreground)
                        .setContentTitle("keep playing the game")
                        .setContentText("you know you want to")
                        .build();



                NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

                    int importance = NotificationManager.IMPORTANCE_HIGH;
                    NotificationChannel channel = new NotificationChannel(CHANNELID, name, importance);
                    channel.setDescription(description);
                    notificationManager.createNotificationChannel(channel);
                    notificationManager.notify(9, notification);

                }


            }
        }, 1000, 3000);

    }
}

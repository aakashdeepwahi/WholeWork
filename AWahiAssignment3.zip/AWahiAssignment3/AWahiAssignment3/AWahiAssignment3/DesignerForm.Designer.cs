﻿
namespace AWahiAssignment3
{
    partial class FormDesign
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormDesign));
            this.mnustpDesign = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gbInsertingTools = new System.Windows.Forms.GroupBox();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.tbColumns = new System.Windows.Forms.TextBox();
            this.lblColumns = new System.Windows.Forms.Label();
            this.tbRows = new System.Windows.Forms.TextBox();
            this.lblRows = new System.Windows.Forms.Label();
            this.gbToolbox = new System.Windows.Forms.GroupBox();
            this.btnGreenBox = new System.Windows.Forms.Button();
            this.btnRedBox = new System.Windows.Forms.Button();
            this.btnGreenDoor = new System.Windows.Forms.Button();
            this.btnRedDoor = new System.Windows.Forms.Button();
            this.btnWall = new System.Windows.Forms.Button();
            this.btnNone = new System.Windows.Forms.Button();
            this.lblToolBox = new System.Windows.Forms.Label();
            this.gbDesigningArea = new System.Windows.Forms.GroupBox();
            this.mnustpDesign.SuspendLayout();
            this.gbInsertingTools.SuspendLayout();
            this.gbToolbox.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnustpDesign
            // 
            this.mnustpDesign.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.mnustpDesign.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.mnustpDesign.Location = new System.Drawing.Point(0, 0);
            this.mnustpDesign.Name = "mnustpDesign";
            this.mnustpDesign.Padding = new System.Windows.Forms.Padding(6, 3, 0, 3);
            this.mnustpDesign.Size = new System.Drawing.Size(800, 30);
            this.mnustpDesign.TabIndex = 0;
            this.mnustpDesign.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(46, 24);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(173, 26);
            this.saveToolStripMenuItem.Text = "&Save";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(173, 26);
            this.exitToolStripMenuItem.Text = "E&xit";
            // 
            // gbInsertingTools
            // 
            this.gbInsertingTools.Controls.Add(this.btnGenerate);
            this.gbInsertingTools.Controls.Add(this.tbColumns);
            this.gbInsertingTools.Controls.Add(this.lblColumns);
            this.gbInsertingTools.Controls.Add(this.tbRows);
            this.gbInsertingTools.Controls.Add(this.lblRows);
            this.gbInsertingTools.Location = new System.Drawing.Point(0, 31);
            this.gbInsertingTools.Name = "gbInsertingTools";
            this.gbInsertingTools.Size = new System.Drawing.Size(800, 57);
            this.gbInsertingTools.TabIndex = 1;
            this.gbInsertingTools.TabStop = false;
            // 
            // btnGenerate
            // 
            this.btnGenerate.Location = new System.Drawing.Point(486, 19);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(94, 29);
            this.btnGenerate.TabIndex = 4;
            this.btnGenerate.Text = "Generate";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // tbColumns
            // 
            this.tbColumns.Location = new System.Drawing.Point(296, 20);
            this.tbColumns.Name = "tbColumns";
            this.tbColumns.Size = new System.Drawing.Size(125, 27);
            this.tbColumns.TabIndex = 3;
            // 
            // lblColumns
            // 
            this.lblColumns.AutoSize = true;
            this.lblColumns.Location = new System.Drawing.Point(217, 23);
            this.lblColumns.Name = "lblColumns";
            this.lblColumns.Size = new System.Drawing.Size(73, 20);
            this.lblColumns.TabIndex = 2;
            this.lblColumns.Text = "Columns: ";
            // 
            // tbRows
            // 
            this.tbRows.Location = new System.Drawing.Point(63, 20);
            this.tbRows.Name = "tbRows";
            this.tbRows.Size = new System.Drawing.Size(125, 27);
            this.tbRows.TabIndex = 1;
            // 
            // lblRows
            // 
            this.lblRows.AutoSize = true;
            this.lblRows.Location = new System.Drawing.Point(6, 23);
            this.lblRows.Name = "lblRows";
            this.lblRows.Size = new System.Drawing.Size(51, 20);
            this.lblRows.TabIndex = 0;
            this.lblRows.Text = "Rows: ";
            // 
            // gbToolbox
            // 
            this.gbToolbox.Controls.Add(this.btnGreenBox);
            this.gbToolbox.Controls.Add(this.btnRedBox);
            this.gbToolbox.Controls.Add(this.btnGreenDoor);
            this.gbToolbox.Controls.Add(this.btnRedDoor);
            this.gbToolbox.Controls.Add(this.btnWall);
            this.gbToolbox.Controls.Add(this.btnNone);
            this.gbToolbox.Controls.Add(this.lblToolBox);
            this.gbToolbox.Location = new System.Drawing.Point(11, 93);
            this.gbToolbox.Name = "gbToolbox";
            this.gbToolbox.Size = new System.Drawing.Size(162, 540);
            this.gbToolbox.TabIndex = 2;
            this.gbToolbox.TabStop = false;
            // 
            // btnGreenBox
            // 
            this.btnGreenBox.Font = new System.Drawing.Font("Segoe UI", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnGreenBox.Image = ((System.Drawing.Image)(resources.GetObject("btnGreenBox.Image")));
            this.btnGreenBox.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGreenBox.Location = new System.Drawing.Point(23, 436);
            this.btnGreenBox.Name = "btnGreenBox";
            this.btnGreenBox.Size = new System.Drawing.Size(121, 69);
            this.btnGreenBox.TabIndex = 6;
            this.btnGreenBox.Text = "Green Box";
            this.btnGreenBox.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGreenBox.UseVisualStyleBackColor = true;
            this.btnGreenBox.Click += new System.EventHandler(this.btnGreenBox_Click);
            // 
            // btnRedBox
            // 
            this.btnRedBox.Font = new System.Drawing.Font("Segoe UI", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRedBox.Image = ((System.Drawing.Image)(resources.GetObject("btnRedBox.Image")));
            this.btnRedBox.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRedBox.Location = new System.Drawing.Point(25, 361);
            this.btnRedBox.Name = "btnRedBox";
            this.btnRedBox.Size = new System.Drawing.Size(119, 69);
            this.btnRedBox.TabIndex = 5;
            this.btnRedBox.Text = "Red Box";
            this.btnRedBox.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRedBox.UseVisualStyleBackColor = true;
            this.btnRedBox.Click += new System.EventHandler(this.btnRedBox_Click);
            // 
            // btnGreenDoor
            // 
            this.btnGreenDoor.Font = new System.Drawing.Font("Segoe UI", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnGreenDoor.Image = ((System.Drawing.Image)(resources.GetObject("btnGreenDoor.Image")));
            this.btnGreenDoor.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGreenDoor.Location = new System.Drawing.Point(23, 285);
            this.btnGreenDoor.Name = "btnGreenDoor";
            this.btnGreenDoor.Size = new System.Drawing.Size(121, 69);
            this.btnGreenDoor.TabIndex = 4;
            this.btnGreenDoor.Text = "Green Door";
            this.btnGreenDoor.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGreenDoor.UseVisualStyleBackColor = true;
            this.btnGreenDoor.Click += new System.EventHandler(this.btnGreenDoor_Click);
            // 
            // btnRedDoor
            // 
            this.btnRedDoor.Font = new System.Drawing.Font("Segoe UI", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRedDoor.Image = ((System.Drawing.Image)(resources.GetObject("btnRedDoor.Image")));
            this.btnRedDoor.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRedDoor.Location = new System.Drawing.Point(23, 211);
            this.btnRedDoor.Name = "btnRedDoor";
            this.btnRedDoor.Size = new System.Drawing.Size(121, 69);
            this.btnRedDoor.TabIndex = 3;
            this.btnRedDoor.Text = "Red Door";
            this.btnRedDoor.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRedDoor.UseVisualStyleBackColor = true;
            this.btnRedDoor.Click += new System.EventHandler(this.btnRedDoor_Click);
            // 
            // btnWall
            // 
            this.btnWall.Font = new System.Drawing.Font("Segoe UI", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnWall.Image = ((System.Drawing.Image)(resources.GetObject("btnWall.Image")));
            this.btnWall.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnWall.Location = new System.Drawing.Point(25, 136);
            this.btnWall.Name = "btnWall";
            this.btnWall.Size = new System.Drawing.Size(119, 69);
            this.btnWall.TabIndex = 2;
            this.btnWall.Text = "Wall";
            this.btnWall.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnWall.UseVisualStyleBackColor = true;
            this.btnWall.Click += new System.EventHandler(this.btnWall_Click);
            // 
            // btnNone
            // 
            this.btnNone.Font = new System.Drawing.Font("Segoe UI", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnNone.Image = ((System.Drawing.Image)(resources.GetObject("btnNone.Image")));
            this.btnNone.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNone.Location = new System.Drawing.Point(23, 61);
            this.btnNone.Name = "btnNone";
            this.btnNone.Size = new System.Drawing.Size(121, 69);
            this.btnNone.TabIndex = 1;
            this.btnNone.Text = "None";
            this.btnNone.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNone.UseVisualStyleBackColor = true;
            this.btnNone.Click += new System.EventHandler(this.btnNone_Click);
            // 
            // lblToolBox
            // 
            this.lblToolBox.AutoSize = true;
            this.lblToolBox.Location = new System.Drawing.Point(51, 23);
            this.lblToolBox.Name = "lblToolBox";
            this.lblToolBox.Size = new System.Drawing.Size(63, 20);
            this.lblToolBox.TabIndex = 0;
            this.lblToolBox.Text = "Toolbox";
            // 
            // gbDesigningArea
            // 
            this.gbDesigningArea.Location = new System.Drawing.Point(181, 93);
            this.gbDesigningArea.Name = "gbDesigningArea";
            this.gbDesigningArea.Size = new System.Drawing.Size(619, 540);
            this.gbDesigningArea.TabIndex = 3;
            this.gbDesigningArea.TabStop = false;
            // 
            // FormDesign
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 636);
            this.Controls.Add(this.gbDesigningArea);
            this.Controls.Add(this.gbToolbox);
            this.Controls.Add(this.gbInsertingTools);
            this.Controls.Add(this.mnustpDesign);
            this.MainMenuStrip = this.mnustpDesign;
            this.Name = "FormDesign";
            this.Text = "Design Form";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormDesign_FormClosing);
            this.mnustpDesign.ResumeLayout(false);
            this.mnustpDesign.PerformLayout();
            this.gbInsertingTools.ResumeLayout(false);
            this.gbInsertingTools.PerformLayout();
            this.gbToolbox.ResumeLayout(false);
            this.gbToolbox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void SaveToolStripMenuItem_Click1(object sender, System.EventArgs e)
        {
            throw new System.NotImplementedException();
        }

        private void SaveToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            throw new System.NotImplementedException();
        }


        #endregion

        private System.Windows.Forms.MenuStrip mnustpDesign;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.GroupBox gbInsertingTools;
        private System.Windows.Forms.Label lblRows;
        private System.Windows.Forms.TextBox tbRows;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.TextBox tbColumns;
        private System.Windows.Forms.Label lblColumns;
        private System.Windows.Forms.GroupBox gbToolbox;
        private System.Windows.Forms.Button btnNone;
        private System.Windows.Forms.Label lblToolBox;
        private System.Windows.Forms.Button btnGreenBox;
        private System.Windows.Forms.Button btnRedBox;
        private System.Windows.Forms.Button btnGreenDoor;
        private System.Windows.Forms.Button btnRedDoor;
        private System.Windows.Forms.Button btnWall;
        private System.Windows.Forms.GroupBox gbDesigningArea;
        private System.Windows.Forms.PictureBox[,] pictureBoxs;
    }
}
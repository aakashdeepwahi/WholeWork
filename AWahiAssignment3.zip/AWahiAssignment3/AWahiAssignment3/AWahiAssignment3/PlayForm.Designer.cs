﻿
namespace AWahiAssignment3
{
    partial class FormPlay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gbPlayArea = new System.Windows.Forms.GroupBox();
            this.lblNumMoves = new System.Windows.Forms.Label();
            this.tbNumMoves = new System.Windows.Forms.TextBox();
            this.lblNumRemainingBox = new System.Windows.Forms.Label();
            this.tbNumRemainingBox = new System.Windows.Forms.TextBox();
            this.btnUp = new System.Windows.Forms.Button();
            this.btnDown = new System.Windows.Forms.Button();
            this.btnLeft = new System.Windows.Forms.Button();
            this.btnRight = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(975, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadGameToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // loadGameToolStripMenuItem
            // 
            this.loadGameToolStripMenuItem.Name = "loadGameToolStripMenuItem";
            this.loadGameToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.loadGameToolStripMenuItem.Text = "Load Game";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            // 
            // gbPlayArea
            // 
            this.gbPlayArea.Location = new System.Drawing.Point(0, 23);
            this.gbPlayArea.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbPlayArea.Name = "gbPlayArea";
            this.gbPlayArea.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbPlayArea.Size = new System.Drawing.Size(757, 467);
            this.gbPlayArea.TabIndex = 1;
            this.gbPlayArea.TabStop = false;
            // 
            // lblNumMoves
            // 
            this.lblNumMoves.AutoSize = true;
            this.lblNumMoves.Location = new System.Drawing.Point(767, 40);
            this.lblNumMoves.Name = "lblNumMoves";
            this.lblNumMoves.Size = new System.Drawing.Size(106, 15);
            this.lblNumMoves.TabIndex = 2;
            this.lblNumMoves.Text = "Number of Moves:";
            // 
            // tbNumMoves
            // 
            this.tbNumMoves.Location = new System.Drawing.Point(768, 58);
            this.tbNumMoves.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbNumMoves.Name = "tbNumMoves";
            this.tbNumMoves.ReadOnly = true;
            this.tbNumMoves.Size = new System.Drawing.Size(172, 23);
            this.tbNumMoves.TabIndex = 3;
            // 
            // lblNumRemainingBox
            // 
            this.lblNumRemainingBox.AutoSize = true;
            this.lblNumRemainingBox.Location = new System.Drawing.Point(768, 111);
            this.lblNumRemainingBox.Name = "lblNumRemainingBox";
            this.lblNumRemainingBox.Size = new System.Drawing.Size(162, 15);
            this.lblNumRemainingBox.TabIndex = 4;
            this.lblNumRemainingBox.Text = "Number of Remaining Boxes:";
            // 
            // tbNumRemainingBox
            // 
            this.tbNumRemainingBox.Location = new System.Drawing.Point(768, 128);
            this.tbNumRemainingBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbNumRemainingBox.Name = "tbNumRemainingBox";
            this.tbNumRemainingBox.ReadOnly = true;
            this.tbNumRemainingBox.Size = new System.Drawing.Size(172, 23);
            this.tbNumRemainingBox.TabIndex = 5;
            // 
            // btnUp
            // 
            this.btnUp.Enabled = false;
            this.btnUp.Location = new System.Drawing.Point(835, 323);
            this.btnUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnUp.Name = "btnUp";
            this.btnUp.Size = new System.Drawing.Size(61, 52);
            this.btnUp.TabIndex = 6;
            this.btnUp.Text = "Up";
            this.btnUp.UseVisualStyleBackColor = true;
            this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
            // 
            // btnDown
            // 
            this.btnDown.Enabled = false;
            this.btnDown.Location = new System.Drawing.Point(835, 380);
            this.btnDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDown.Name = "btnDown";
            this.btnDown.Size = new System.Drawing.Size(61, 52);
            this.btnDown.TabIndex = 7;
            this.btnDown.Text = "Down";
            this.btnDown.UseVisualStyleBackColor = true;
            this.btnDown.Click += new System.EventHandler(this.btnDown_Click);
            // 
            // btnLeft
            // 
            this.btnLeft.Enabled = false;
            this.btnLeft.Location = new System.Drawing.Point(768, 380);
            this.btnLeft.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLeft.Name = "btnLeft";
            this.btnLeft.Size = new System.Drawing.Size(61, 52);
            this.btnLeft.TabIndex = 8;
            this.btnLeft.Text = "Left";
            this.btnLeft.UseVisualStyleBackColor = true;
            this.btnLeft.Click += new System.EventHandler(this.btnLeft_Click);
            // 
            // btnRight
            // 
            this.btnRight.Enabled = false;
            this.btnRight.Location = new System.Drawing.Point(901, 380);
            this.btnRight.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnRight.Name = "btnRight";
            this.btnRight.Size = new System.Drawing.Size(61, 52);
            this.btnRight.TabIndex = 9;
            this.btnRight.Text = "Right";
            this.btnRight.UseVisualStyleBackColor = true;
            this.btnRight.Click += new System.EventHandler(this.btnRight_Click);
            // 
            // FormPlay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(975, 500);
            this.Controls.Add(this.btnRight);
            this.Controls.Add(this.btnLeft);
            this.Controls.Add(this.btnDown);
            this.Controls.Add(this.btnUp);
            this.Controls.Add(this.tbNumRemainingBox);
            this.Controls.Add(this.lblNumRemainingBox);
            this.Controls.Add(this.tbNumMoves);
            this.Controls.Add(this.lblNumMoves);
            this.Controls.Add(this.gbPlayArea);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormPlay";
            this.Text = "Play Form";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormPlay_FormClosing);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadGameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.GroupBox gbPlayArea;
        private System.Windows.Forms.Label lblNumMoves;
        private System.Windows.Forms.TextBox tbNumMoves;
        private System.Windows.Forms.Label lblNumRemainingBox;
        private System.Windows.Forms.TextBox tbNumRemainingBox;
        private System.Windows.Forms.Button btnUp;
        private System.Windows.Forms.Button btnDown;
        private System.Windows.Forms.Button btnLeft;
        private System.Windows.Forms.Button btnRight;
        private System.Windows.Forms.PictureBox[,] pictureBoxs;
    }
}
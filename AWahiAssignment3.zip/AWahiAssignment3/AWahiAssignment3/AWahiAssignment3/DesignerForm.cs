﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace AWahiAssignment3
{
    public partial class FormDesign : Form
    {
        private Form previousForm; 

        //Declaring Of Constants
        private const int IMAGE_OFFSET = 30;
        private const int IMAGE_HEIGHT = 50;
        private const int IMAGE_WIDTH = 50;

        //Declaring Int Variables
        private int countWall;
        private int countDoors;
        private int countBoxes;

        //Declaration of Enum
        private ImageType selectedImageType;

        //1D Array 
        private Image[] imgs;

        //2D Array
        private ImageType[,] imageTypes;

        //Assigning values to Enum
        enum ImageType
        {
            None = 0,
            Wall = 1,
            RedDoor = 2,
            GreenDoor = 3,
            RedBox = 4,
            GreenBox = 5
        }

        public FormDesign(Form previousForm)
        {
            InitializeComponent();
            //these lines are added over here due to the error which I was facing in 86 & 87, 78 & 79. Its the error for menustrip
            this.saveToolStripMenuItem.Click += OnSave_Click;
            this.exitToolStripMenuItem.Click += OnExit_Click;

            this.previousForm = previousForm;
            
            selectedImageType = ImageType.None;
            
            //Assigning Valuess to Array
            imgs = new Image[6];
            imgs[0] = Properties.Resources.none;
            imgs[1] = Properties.Resources.wall;
            imgs[2] = Properties.Resources.reddoor;
            imgs[3] = Properties.Resources.greendoor;
            imgs[4] = Properties.Resources.redbox;
            imgs[5] = Properties.Resources.greenbox;

            countWall = 0;
            countDoors = 0;
            countBoxes = 0;
        }

        private void FormDesign_FormClosing(object sender, FormClosingEventArgs e)
        {
            previousForm.Show();
            this.Hide();
        }


        //If u write anything in the code or will just press any key in code you have to add the next line in  the DesignerForm.Designer.cs in the exitToolStripMenuItem
        // this.exitToolStripMenuItem.Click += OnExit_Click;
        private void OnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        //If u write anything in the code or will just press any key in code you have to add the next line in  the DesignerForm.Designer.cs in the saveToolStripMenuItem
        // this.saveToolStripMenuItem.Click += OnSave_Click;
        private void OnSave_Click(object sender, EventArgs e)
        {
            //Save Game File
            SaveFileDialog GameLevel = new SaveFileDialog();
            GameLevel.Filter = "Game File|*.qgame";
            GameLevel.FileName = "AWahiAssignment3Level1";
            GameLevel.Title = "Save Game File";
            
            //If image types are not set then error
            if (imageTypes == null)
            {
                MessageBox.Show("Please provide valid game.", "QGame", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }else if (GameLevel.ShowDialog() != System.Windows.Forms.DialogResult.OK)
            {
                MessageBox.Show("Game is not saved!", "QGame", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string path = GameLevel.FileName;
            StreamWriter WriteFile = new StreamWriter(File.Create(path));
            int rows = imageTypes.GetLength(0), cols = imageTypes.GetLength(1);
            //Save total rows and columns
            WriteFile.WriteLine(rows);
            WriteFile.WriteLine(cols);
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    //Save rowNumber, columnNumber and imageType
                    WriteFile.WriteLine(i);
                    WriteFile.WriteLine(j);
                    //WriteFile.WriteLine((int)imageTypes[i, j]);
                    
                    ImageType iT = imageTypes[i, j];
                    int iTNum = (int)iT;
                    WriteFile.WriteLine(iTNum);
                }
            }
            WriteFile.Dispose();
            MessageBox.Show("File Saved Successfully! \nTotal Number of Walls: "+countWall.ToString()+ " \nTotal Number of Doors: "+countDoors.ToString()+ " \nTotal Number of Boxes: "+countBoxes.ToString(), "QGame", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            int rows; //Will come from TextBox
            int cols; //Will come from TextBox
            //If row and columns are not integer or they are negetive number then error
            if (!int.TryParse(tbRows.Text, out rows) || !int.TryParse(tbColumns.Text, out cols) || rows<=0 || cols<=0)
            {
                MessageBox.Show("Please provide valid data for rows and columns (Both must be integers)", "QGame", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //Clear the previous images
            this.gbDesigningArea.Controls.Clear();
            //Initialize Arrays
            this.pictureBoxs = new PictureBox[rows, cols];
            imageTypes = new ImageType[rows, cols];
            for (int i=0; i<rows; i++)
            {
                for (int j=0; j<cols; j++)
                {
                    //Initialize picturebox and initialize imageTypes to none
                    this.pictureBoxs[i, j] = InitPictureBox(i, j);
                    imageTypes[i, j] = ImageType.None;
                }
            }
        }


        // Storing Image in Button
        private void btnNone_Click(object sender, EventArgs e)
        {
            selectedImageType = ImageType.None;
        }

        private void btnWall_Click(object sender, EventArgs e)
        {
            selectedImageType = ImageType.Wall;
        }

        private void btnRedDoor_Click(object sender, EventArgs e)
        {
            selectedImageType = ImageType.RedDoor;
        }

        private void btnGreenDoor_Click(object sender, EventArgs e)
        {
            selectedImageType = ImageType.GreenDoor;
        }

        private void btnRedBox_Click(object sender, EventArgs e)
        {
            selectedImageType = ImageType.RedBox;
        }
        private void btnGreenBox_Click(object sender, EventArgs e)
        {
            selectedImageType = ImageType.GreenBox;
        }



        private PictureBox InitPictureBox(int row, int col)
        {
            PictureBox box = new PictureBox();
            this.gbDesigningArea.Controls.Add(box);
            box.BackgroundImage = Properties.Resources.none;
            box.Location = new System.Drawing.Point(IMAGE_OFFSET+(col*IMAGE_WIDTH), IMAGE_OFFSET+(row*IMAGE_HEIGHT));
            box.Name = "pictureBox_"+row.ToString()+"_"+col.ToString();
            box.Size = new System.Drawing.Size(IMAGE_HEIGHT, IMAGE_WIDTH);
            box.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            box.TabIndex = 0;
            box.TabStop = false;
            box.MouseClick += (sender, EventArgs) => { pictureBox_Click(sender, EventArgs, row, col); };
            return box;
        }

        private void pictureBox_Click(object sender, EventArgs e, int row, int col)
        {
            PictureBox box = (PictureBox)sender;
            //Change image of picturebox
            box.BackgroundImage = imgs[(int)selectedImageType];
            //Change count
            ChangeImageTypeCount(imageTypes[row, col], selectedImageType);
            //Change image type
            imageTypes[row, col] = selectedImageType;
        }

        private void ChangeImageTypeCount(ImageType previousType, ImageType newType)
        {
            if (previousType == newType) return;

            if (previousType == ImageType.Wall) countWall--;
            else if (previousType == ImageType.RedDoor || previousType == ImageType.GreenDoor) countDoors--;
            else if (previousType == ImageType.RedBox || previousType == ImageType.GreenBox) countBoxes--;

            if (newType == ImageType.Wall) countWall++;
            else if (newType == ImageType.RedDoor || newType == ImageType.GreenDoor) countDoors++;
            else if (newType == ImageType.RedBox || newType == ImageType.GreenBox) countBoxes++;
        }
    }
}

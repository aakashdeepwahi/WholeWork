﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AWahiAssignment3
{
    public partial class ControlForm : Form
    {
        public ControlForm()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //Exits the file
            Application.Exit();
        }

        private void btnDesign_Click(object sender, EventArgs e)
        {
            //defining new form which is form 2
            FormDesign mazeDesignerForm = new FormDesign(this);
            //hides the form 1
            this.Hide();
            //Opening of new form 
            mazeDesignerForm.ShowDialog();
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            //defining new form which is form 3
            FormPlay playGameForm = new FormPlay(this);
            //hides the form 1
            this.Hide();
            //Opening of new form 
            playGameForm.ShowDialog();
        }

        private void ControlForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void ControlForm_Load(object sender, EventArgs e)
        {

        }
    }
}

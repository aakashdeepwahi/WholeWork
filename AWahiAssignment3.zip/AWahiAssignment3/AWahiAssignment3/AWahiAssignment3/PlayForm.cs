﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace AWahiAssignment3
{
    public partial class FormPlay : Form
    {
        private Form previousForm;

        // Declaring of Constants
        private const int LINES_PER_CELL = 3;
        private const int MIN_LINES_IN_FILE = 2;
        private const int TOTAL_IMAGE_TYPE = 6;
        private const int IMAGE_OFFSET = 30;
        private const int IMAGE_HEIGHT = 50;
        private const int IMAGE_WIDTH = 50;

        //2D Array
        private ImageType[,] imageTypes;

        //1D Array
        private Image[] imgs;

        //Declaring Integers
        private int selectedRow;
        private int selectedCol;
        private int totalMoves;
        private int totalRemainingBoxes;


        //Assigning values to Enum
        enum ImageType
        {
            None = 0,
            Wall = 1,
            RedDoor = 2,
            GreenDoor = 3,
            RedBox = 4,
            GreenBox = 5
        }

        public FormPlay(Form previousForm)
        {
            InitializeComponent();
            //these lines are added over here due to the error which I was facing in 86 & 87, 93 & 94. Its the error for menustrip
            this.loadGameToolStripMenuItem.Click += OnLoadGame_Click;
            this.exitToolStripMenuItem.Click += OnExit_Click;

            //Saving So that we can call the control Form When it is closed
            this.previousForm = previousForm;

            //Save Image from Resources in Array so that images can be received by using index(ImageType)
            imgs = new Image[6];
            imgs[0] = Properties.Resources.none;
            imgs[1] = Properties.Resources.wall;
            imgs[2] = Properties.Resources.reddoor;
            imgs[3] = Properties.Resources.greendoor;
            imgs[4] = Properties.Resources.redbox;
            imgs[5] = Properties.Resources.greenbox;

            //Selected Row and Col = -1 means No Row and Col is selected
            selectedRow = -1;
            selectedCol = -1;

            //Set Text in TextBox
            totalMoves = 0;
            tbNumMoves.Text = totalMoves.ToString();
            totalRemainingBoxes = 0;
            tbNumRemainingBox.Text = totalRemainingBoxes.ToString();
        }

        private void FormPlay_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Calling the Control Form then Closing the current form 
            previousForm.Show();
            this.Hide();
        }


        //If u write anything in the code or will just press any key in code you have to add the next line in  the PlayForm.Designer.cs in the exitToolStripMenuItem
        // this.exitToolStripMenuItem.Click += OnExit_Click;
        private void OnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //If u write anything in the code or will just press any key in code you have to add the next line in  the PlayForm.Designer.cs in the loadToolStripMenuItem
        // this.loadToolStripMenuItem.Click += OnLoad_Click;
        private void OnLoadGame_Click(object sender, EventArgs e)
        {
            //Load the Game File
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Title = "Load Game File";
            dialog.Filter = "Game File|*.qgame";
            dialog.InitialDirectory = @"C:\";

            //if Game File is not selected then return
            if (dialog.ShowDialog() != DialogResult.OK) return;
            
            ResetGame();

            //Read lines from file
            string[] filelines = File.ReadAllLines(dialog.FileName);

            // Will get from file
            int rows;
            int cols; 
            
            //if file does not have atleast 2 lines(rows and columns), if row and column are not integer, if rows and columns are less then or equal to 0 then Error
            //total number of cells = rows * cols
            //if total lines in file is not equal to (minimun lines in file + (total number of cells * lines per cell)) then Error
            if(filelines.Length<MIN_LINES_IN_FILE || !int.TryParse(filelines[0], out rows) || !int.TryParse(filelines[1], out cols) || rows <= 0 || cols <= 0 || filelines.Length!=(MIN_LINES_IN_FILE+(rows*cols*LINES_PER_CELL)))
            {
                MessageBox.Show("Corrupted Game File!", "QGame", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //2D array of picture box
            this.pictureBoxs = new PictureBox[rows, cols];
            //2D array of ImageTypes
            imageTypes = new ImageType[rows, cols];
            int totalCells = rows * cols;
            for (int i=0; i<totalCells; i++)
            {
                //Will get from file
                int rowNum;
                int colNum;
                int imageTypeNum; 
                
                
                //Read 3 lines for 1 cell, if values are not integer or values are out of range then Error
                if (!int.TryParse(filelines[MIN_LINES_IN_FILE+(LINES_PER_CELL *i)], out rowNum) || !int.TryParse(filelines[MIN_LINES_IN_FILE+(LINES_PER_CELL*i)+1], out colNum) || !int.TryParse(filelines[MIN_LINES_IN_FILE+(LINES_PER_CELL*i)+2], out imageTypeNum) || rowNum<0 || rowNum>=rows || colNum<0 || colNum>=cols || imageTypeNum<0 || imageTypeNum>=TOTAL_IMAGE_TYPE)
                {
                    MessageBox.Show("Corrupted Game File!", "QGame", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                //Set the picturebox in groupbox
                this.pictureBoxs[rowNum, colNum] = InitPictureBox(rowNum, colNum, imageTypeNum);
                //Set the imageType in array
                imageTypes[rowNum, colNum] = (ImageType)imageTypeNum;

                //Count the number of box
                if (imageTypes[rowNum, colNum] == ImageType.RedBox || imageTypes[rowNum, colNum] == ImageType.GreenBox) totalRemainingBoxes++;
            }

            //Set text in Textbox
            tbNumRemainingBox.Text = totalRemainingBoxes.ToString();
            //Enable the left, right, up, down button
            ControlButtonsEnabled(true);
        }

        private void ControlButtonsEnabled(bool isEnable)
        {
            //Fuction For enabling every Button for Controlling
            this.btnUp.Enabled = isEnable;
            this.btnDown.Enabled = isEnable;
            this.btnLeft.Enabled = isEnable;
            this.btnRight.Enabled = isEnable;
        }

        private PictureBox InitPictureBox(int row, int col, int imageTypeNum)
        {
            // Generating Picture Boxes to the Game
            PictureBox box = new PictureBox();
            this.gbPlayArea.Controls.Add(box);
            box.BackgroundImage = imgs[imageTypeNum];
            box.Location = new System.Drawing.Point(IMAGE_OFFSET + (col * IMAGE_WIDTH), IMAGE_OFFSET + (row * IMAGE_HEIGHT));
            box.Name = "pictureBox_" + row.ToString() + "_" + col.ToString();
            box.Size = new System.Drawing.Size(IMAGE_HEIGHT, IMAGE_WIDTH);
            box.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            box.TabIndex = 0;
            box.TabStop = false;
            box.MouseClick += (sender, EventArgs) => { pictureBox_Click(sender, EventArgs, row, col); };
            return box;
        }

        private void pictureBox_Click(object sender, EventArgs e, int row, int col)
        {
            //if clicked image is not a Box then return
            if (imageTypes[row, col] != ImageType.GreenBox && imageTypes[row, col] != ImageType.RedBox) return;

            //Fix the previously selected box's border
            if(selectedRow!=-1 && selectedCol!=-1) pictureBoxs[selectedRow, selectedCol].BorderStyle = BorderStyle.None;
            
            //Set the selected row and col
            selectedRow = row;
            selectedCol = col;

            //Set the currently selected box's border
            pictureBoxs[row, col].BorderStyle = BorderStyle.Fixed3D;
        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            //Vertically move up = -1
            MoveBox(0, -1);
        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            //Vertically move down = 1
            MoveBox(0, 1);
        }

        private void btnLeft_Click(object sender, EventArgs e)
        {
            //Horizontally move left = -1
            MoveBox(-1, 0);
        }

        private void btnRight_Click(object sender, EventArgs e)
        {
            //Horizontally move right = 1
            MoveBox(1, 0);
        }

        private void MoveBox(int horizontalMove, int verticalMove)
        {
            //if control buttons are clicked but box is not selected then return
            if(selectedRow == -1 || selectedCol == -1)
            {
                MessageBox.Show("Click on Box to Move!", "QGame", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            //Increment totalMoves and set in TextBox
            totalMoves++;
            tbNumMoves.Text = totalMoves.ToString();

            ImageType selectedImageType = imageTypes[selectedRow, selectedCol];
            int rows = imageTypes.GetLength(0), cols = imageTypes.GetLength(1);
            int i;
            int j;
            //Loop will start from selected box, it will move according to Vertical and Horizontal move, until out of range
            for (i = selectedRow + verticalMove, j = selectedCol + horizontalMove; i >= 0 && i < rows && j >= 0 && j < cols; i += verticalMove, j+= horizontalMove)
            {
                // Stop when it has found a box which is not None
                if (imageTypes[i, j] != ImageType.None)
                {
                    //If current image is redDoor and selected image is redbox
                    if(imageTypes[i, j] == ImageType.RedDoor && imageTypes[selectedRow, selectedCol] == ImageType.RedBox)
                    {
                        //Set the selected image = None
                        ChangePictureBoxImage(selectedRow, selectedCol, ImageType.None);
                        //No Box is selected
                        selectedRow = -1;
                        selectedCol = -1;
                        //Decrecent count
                        totalRemainingBoxes--;
                    }

                    //If current image is greenDoor and selected image is greenbox
                    else if (imageTypes[i, j] == ImageType.GreenDoor && imageTypes[selectedRow, selectedCol] == ImageType.GreenBox)
                    {
                        //Set the selected image = None
                        ChangePictureBoxImage(selectedRow, selectedCol, ImageType.None);
                        //No Box is selected
                        selectedRow = -1;
                        selectedCol = -1;
                        //Decrecent count
                        totalRemainingBoxes--;
                    }

                    //if it's not a door then move the selected image to the new position
                    else
                    {
                        //Set the selected image = None
                        ChangePictureBoxImage(selectedRow, selectedCol, ImageType.None);
                        //Set the new selected image = image type
                        ChangePictureBoxImage(i - verticalMove, j - horizontalMove, selectedImageType);
                        //Change selected position to new position
                        selectedRow = i- verticalMove;
                        selectedCol = j- horizontalMove;
                    }

                    tbNumRemainingBox.Text = totalRemainingBoxes.ToString();
                    //if there are no boxes left
                    if(totalRemainingBoxes == 0)
                    {
                        MessageBox.Show("Congratulations! \nGame End!", "QGame", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ResetGame();
                    }
                    
                    return;
                }
            }

            //if loop has gone out of range then move image to last position
            ChangePictureBoxImage(selectedRow, selectedCol, ImageType.None);
            ChangePictureBoxImage(i - verticalMove, j - horizontalMove, selectedImageType);
            selectedRow = i - verticalMove;
            selectedCol = j - horizontalMove;
        }

        private void ChangePictureBoxImage(int row, int col, ImageType iType)
        {
            imageTypes[row, col] = iType;
            pictureBoxs[row, col].BackgroundImage = imgs[(int)iType];
            //if iType is None then borderStyle = None else borderStyle = Fixed3d
            pictureBoxs[row, col].BorderStyle = (iType == ImageType.None) ? BorderStyle.None : BorderStyle.Fixed3D;
        }

        //if game end then reset everything
        private void ResetGame()
        {
            selectedRow = -1;
            selectedCol = -1;

            totalMoves = 0;
            tbNumMoves.Text = totalMoves.ToString();
            totalRemainingBoxes = 0;
            tbNumRemainingBox.Text = totalRemainingBoxes.ToString();

            this.gbPlayArea.Controls.Clear();

            ControlButtonsEnabled(false);
        }
    }
}
